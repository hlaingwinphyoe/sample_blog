<?php
//==============COMMON START===================

function alert($data,$color="danger"){
    return "<div class='alert alert-$color alert-dismissible fade show' role='alert'>
           $data
              <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                <span aria-hidden='true'>&times;</span>
              </button>
           </div>";
}

function runQuery($sql){
    if (mysqli_query(con(),$sql)){
        return true;
    }else{
        die("DB Error :".mysqli_error());
    }
}

function redirect($l){
    header("location:$l");
}

//==============COMMON END===================


//==============AUTH START===================

function register(){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password == $cpassword){
        $sPass = password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$sPass')";
        if (runQuery($sql)){
            redirect("login.php");
        }
    }else{
        alert("Password don't match");
    }
}

function login(){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query(con(),$sql);
    $row = mysqli_fetch_assoc($query);
    if (!$row){
        return alert("Invalid Email or Password");
    }else{
        if (!password_verify($password,$row['password'])){
            return alert("Invalid Email or Password");
        }else{
            session_start();
            $_SESSION['user'] =$row;
            redirect("dashboard.php");
        }

    }
}

//==============AUTH END=====================